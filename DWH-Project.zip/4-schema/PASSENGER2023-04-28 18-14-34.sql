ALTER SESSION SET CURRENT_SCHEMA = AIRLINE;

--DDL Script for TABLE "AIRLINE"."PASSENGER"
CREATE TABLE "AIRLINE"."PASSENGER"     
( 
			"ID" NUMBER, 
		  "FNAME" VARCHAR2(20), 
		  "LNAME" VARCHAR2(20), 
		  "ADDRESS" VARCHAR2(50), 
		  "PHONE_NUMBER" VARCHAR2(50), 
		  "FREQUENT_USER" NUMBER(*,0), 
		  "MILES" NUMBER, 
CONSTRAINT "PASSENGER_PK" PRIMARY KEY ("ID")   
USING INDEX 
PCTFREE 10 
INITRANS 2 
MAXTRANS 255 
COMPUTE STATISTICS    
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "SYSTEM"  ENABLE    ) SEGMENT CREATION IMMEDIATE    
PCTFREE 10 PCTUSED 40 
INITRANS 1 
MAXTRANS 255 NOCOMPRESS LOGGING   
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "SYSTEM";
 


insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (1,'Ali','Montgomery','18 S Rose Hill Ln','(127) 802-1232',0,1200);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (2,'Kay','Still','711 South Riddle Hill Loop','(339) 447-4592',0,3400);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (3,'Linsey','Dayton','241 East Riverside Highway','(706) 281-1301',1,5500);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (4,'Sonny','Gagnon','1679 South Lake Lane','(894) 004-6963',0,400);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (5,'King','Christie','394 Pine Tree Cir','(278) 461-3711',0,864);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (6,'Natashia','Kinsey','552 Red Riverview Circle','(679) 246-9791',0,651);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (7,'Adela','Wimberly','492 South Brentwood Ln','(643) 153-6340',0,4000);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (8,'Zelma','Deal','256 Oak Court','(687) 435-7242',1,5641);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (9,'Bertram','Mcclain','361 Meadowview Way','(371) 519-3365',0,130);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (10,'Chas','Beyer','1191 SW Rushwood Ln','(471) 150-3046',1,969);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (11,'Diedre','Kirby','3266 E Stonewood Pkwy','(836) 063-8549',0,5411);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (12,'Alesha','Christman','28 E Riverside Ln','(174) 588-7666',1,4400);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (13,'Myles','Mcclanahan','2520 White Mountain Ct','(651) 739-9499',0,500);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (14,'August','Stillwell','809 N Quailwood Ct','(704) 286-7164',1,5156);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (15,'Mike','Bible','2249 Red Ashwood Drive','(781) 798-5014',1,741);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (16,'Ima','Gaines','1812 NW Parkwood Parkway','(475) 273-2282',0,561);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (17,'Ronald','Kirchner','1266 Riverside Loop','(802) 668-0849',1,1254);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (18,'Curtis','Christopher','2879 New Glenwood Court','(173) 497-1480',1,5899);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (19,'Moses','Mcclellan','423 East Lake Hwy','(798) 152-9975',1,1554);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (20,'Lavonda','Dean','940 Red Hazelwood Court','(713) 575-3927',1,546);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (21,'Adrienne','Kirk','296 Riddle Hill Hwy','(749) 606-4410',1,1596);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (22,'Abbie','Winchester','652 West Glenwood Cir','(287) 009-0072',1,1254);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (23,'Deon','Quezada','116 Deepwood Rd','(470) 615-8614',1,988);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (24,'Salley','Stiltner','3205 Ashwood Way','(290) 369-4073',0,5621);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (25,'Stephan','Windham','2862 New Sharp Hill Ct','(394) 438-0689',1,4100);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (26,'Amado','Montoya','39 New Meadowview Avenue','(334) 461-0483',0,1400);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (27,'Adrienne','Gainey','1829 Rushwood Loop','(659) 374-9732',0,156);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (28,'Alayna','Quick','255 Red Buttonwood Loop','(926) 277-5290',1,515);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (29,'Marilou','Stine','761 Hope Circle','(879) 778-1880',1,1478);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (30,'Emerson','Winfield','3949 Chapel Hill Parkway','(909) 342-6669',1,985);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (31,'Addie','Deaton','511 E Edgewood Blvd','(793) 365-7262',0,654);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (32,'Abraham','Bickford','48 East Hunting Hill Hwy','(260) 584-1320',1,5789);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (33,'Lenard','Gaither','3047 Rose Hill Dr','(791) 103-9940',1,3245);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (34,'Dionna','Decker','807 Brentwood Way','(655) 379-7141',1,1254);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (35,'Jarrett','Stinnett','144 New Farmview Pkwy','(118) 404-3021',0,987);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (36,'Adaline','Moody','69 E Ski Hill Highway','(339) 729-9338',0,875);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (37,'Bao','Mcclelland','806 SE Chapel Hill St','(419) 427-8785',0,1546);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (38,'Nikita','Galarza','2201 Old Highland Loop','(146) 646-6960',0,321);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (39,'Floyd','Christy','645 Monument Avenue','(572) 247-6407',0,3216);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (40,'Aleta','Dees','53 East Ironwood Avenue','(262) 478-0233',1,5487);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (41,'Darline','Winfrey','287 Market St','(487) 077-9200',1,3258);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (42,'Billy','Biddle','84 Riverview Loop','(216) 484-0548',1,1987);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (43,'Korey','Quigley','74 4th Rd','(725) 316-3589',1,3246);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (44,'Maryjo','Moon','13 Pine Tree Ln','(229) 566-5157',0,974);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (45,'Cinda','Quinlan','1132 NW Prospect Hill Drive','(990) 003-6751',1,324);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (46,'Douglas','Chu','2999 E Chapel Hill Ln','(434) 950-8187',0,1346);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (47,'Abigail','Galbraith','1919 Meadowview Highway','(443) 987-6740',1,687);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (48,'Adan','Dehart','77 New Hunting Hill Ct','(617) 153-3774',0,349);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (49,'Shanon','Mooney','569 Mountain Parkway','(634) 102-0281',0,478);
insert into "PASSENGER"("ID","FNAME","LNAME","ADDRESS","PHONE_NUMBER","FREQUENT_USER","MILES") values (50,'Abby','Quinn','85 Sharp Hill St','(684) 990-2306',0,1850);
