ALTER SESSION SET CURRENT_SCHEMA = AIRLINE;

--DDL Script for TABLE "AIRLINE"."LOCATION"
CREATE TABLE "AIRLINE"."LOCATION"     
( 
			"LOCATION_ID" NUMBER(10,0), 
		  "COUNTRY" VARCHAR2(255) NOT NULL ENABLE, 
		  "REGION" VARCHAR2(255) NOT NULL ENABLE, 
CONSTRAINT "LOCATION_R01" PRIMARY KEY ("LOCATION_ID")   
USING INDEX 
PCTFREE 10 
INITRANS 2 
MAXTRANS 255 
COMPUTE STATISTICS    
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "SYSTEM"  ENABLE    ) SEGMENT CREATION IMMEDIATE    
PCTFREE 10 PCTUSED 0 
INITRANS 1 
MAXTRANS 255 NOCOMPRESS LOGGING   
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "USERS";
 


insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (1,'France','KY-SC');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (2,'Suriname','KS-UN');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (3,'Philippines','IL-DM');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (4,'Albania','IL-DG');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (5,'Austria','MS-WG');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (6,'Cuba','CT-BG');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (7,'Philippines','AZ-WE');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (8,'Hungary','KS-VG');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (9,'Portugal','WV-HM');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (10,'Nigeria','VA-VN');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (11,'Zambia','NV-QY');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (12,'Finland','MD-TS');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (13,'United Kingdom','WI-MG');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (14,'Romania','SD-DM');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (15,'Malawi','PA-DV');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (16,'Iceland','KS-SV');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (17,'Denmark','MA-HL');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (18,'Gambia','MD-CU');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (19,'Jordan','UT-WX');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (20,'Japan','VA-ET');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (21,'Ireland','OR-TY');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (22,'Uruguay','WV-BQ');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (23,'Romania','ME-ZN');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (24,'Turkey','ID-XC');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (25,'Nicaragua','NE-XS');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (26,'Latvia','CT-JR');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (27,'Mongolia','IN-TI');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (28,'Pakistan','ME-GN');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (29,'Kenya','ME-ZJ');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (30,'Kuwait','NC-MX');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (31,'India','MS-QB');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (32,'Mauritania','DE-CR');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (33,'Philippines','CT-PP');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (34,'Iraq','AK-KH');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (35,'South Africa','MD-CB');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (36,'Korea','MS-OU');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (37,'Viet Nam','WA-WB');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (38,'Lebanon','TN-VY');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (39,'United Kingdom','ME-NT');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (40,'Nepal','CA-PA');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (41,'Finland','OR-MZ');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (42,'Australia','CA-DP');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (43,'Bulgaria','FL-DE');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (44,'Iceland','SD-UW');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (45,'Afghanistan','MA-QB');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (46,'Qatar','UT-SJ');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (47,'Korea','RI-IB');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (48,'Croatia','WV-RG');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (49,'Malta','NV-MB');
insert into "LOCATION"("LOCATION_ID","COUNTRY","REGION") values (50,'Bangladesh','UT-WU');
