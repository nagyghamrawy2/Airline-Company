ALTER SESSION SET CURRENT_SCHEMA = AIRLINE;

--DDL Script for TABLE "AIRLINE"."FLIGHT"
CREATE TABLE "AIRLINE"."FLIGHT"     
( 
			"ID" NUMBER, 
		  "DEPARTURE_AIRPORT" VARCHAR2(20), 
		  "ARRIVAL_AIRPORT" VARCHAR2(20), 
		  "FLIGHT_MILES" NUMBER, 
CONSTRAINT "FLIGHT_PK" PRIMARY KEY ("ID")   
USING INDEX 
PCTFREE 10 
INITRANS 2 
MAXTRANS 255 
COMPUTE STATISTICS    
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "SYSTEM"  ENABLE    ) SEGMENT CREATION IMMEDIATE    
PCTFREE 10 PCTUSED 40 
INITRANS 1 
MAXTRANS 255 NOCOMPRESS LOGGING   
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "SYSTEM";
 


insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1005,'Tripoli Airport','Sharjah Airport',4564);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1006,'Sharjah Airport','Madinah Airport',8501);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1007,'Hurghada Airport','Istanbul Airport',2150);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1008,'Aden Airport','Istanbul Airport',1478);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1009,'Sharjah Airport','Doha Airport',2365);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1010,'Doha Airport','Tripoli Airport',4545);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1011,'Sharjah Airport','Sharjah Airport',1486);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1012,'Sharjah Airport','Gassim Airport',2369);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1013,'Doha Airport','Istanbul Airport',400);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1014,'Abuja Airport','Sharjah Airport',5566);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1015,'Aden Airport','Gassim Airport',8484);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1016,'Tripoli Airport','Sharjah Airport',587);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1017,'Doha Airport','Gassim Airport',2548);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1018,'Gassim Airport','Doha Airport',1548);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1019,'Beirut Airport','Doha Airport',3124);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1020,'Istanbul Airport','Beirut Airport',1874);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1021,'Istanbul Airport','Istanbul Airport',2334);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1022,'Sharjah Airport','Sharjah Airport',1587);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1023,'Istanbul Airport','Doha Airport',2854);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1024,'Doha Airport','Doha Airport',3649);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1025,'Tripoli Airport','Doha Airport',1548);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1026,'Sharjah Airport','Beirut Airport',6498);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1027,'Beirut Airport','Doha Airport',1458);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1028,'Gassim Airport','Tripoli Airport',220);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1029,'Hurghada Airport','Abuja Airport',1548);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1030,'Istanbul Airport','Tripoli Airport',850);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1031,'Sharjah Airport','Istanbul Airport',1454);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1032,'Abuja Airport','Sharjah Airport',4121);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1033,'Hurghada Airport','Madinah Airport',4652);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1034,'Abuja Airport','Gassim Airport',1850);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1035,'Sharjah Airport','Doha Airport',1492);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1036,'Abuja Airport','Aden Airport',340);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1037,'Aden Airport','Beirut Airport',430);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1038,'Istanbul Airport','Beirut Airport',978);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1039,'Beirut Airport','Gassim Airport',156);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1040,'Tripoli Airport','Tripoli Airport',1587);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1041,'Istanbul Airport','Istanbul Airport',2659);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1042,'Aden Airport','Abuja Airport',5165);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1043,'Hurghada Airport','Madinah Airport',1587);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1044,'Sharjah Airport','Madinah Airport',269);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1045,'Hurghada Airport','Istanbul Airport',1598);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1046,'Istanbul Airport','Beirut Airport',1458);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1047,'Istanbul Airport','Abuja Airport',1587);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1048,'Gassim Airport','Aden Airport',326);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1049,'Beirut Airport','Doha Airport',987);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1050,'Beirut Airport','Beirut Airport',1448);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1051,'Sharjah Airport','Beirut Airport',1587);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1052,'Abuja Airport','Madinah Airport',2165);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1053,'Madinah Airport','Aden Airport',147);
insert into "FLIGHT"("ID","DEPARTURE_AIRPORT","ARRIVAL_AIRPORT","FLIGHT_MILES") values (1054,'Istanbul Airport','Madinah Airport',1548);
