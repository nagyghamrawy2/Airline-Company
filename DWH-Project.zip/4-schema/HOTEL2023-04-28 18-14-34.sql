ALTER SESSION SET CURRENT_SCHEMA = AIRLINE;

--DDL Script for TABLE "AIRLINE"."HOTEL"
CREATE TABLE "AIRLINE"."HOTEL"     
( 
			"ID" NUMBER, 
		  "NAME" VARCHAR2(100), 
		  "STARS" NUMBER(*,0) NOT NULL ENABLE, 
CONSTRAINT "HOTEL_PK" PRIMARY KEY ("ID")   
USING INDEX 
PCTFREE 10 
INITRANS 2 
MAXTRANS 255 
COMPUTE STATISTICS    
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "SYSTEM"  ENABLE    ) SEGMENT CREATION IMMEDIATE    
PCTFREE 10 PCTUSED 40 
INITRANS 1 
MAXTRANS 255 NOCOMPRESS LOGGING   
STORAGE (
        INITIAL 65536 
        NEXT 1048576 
        MINEXTENTS 1 
        MAXEXTENTS 2147483645   
        PCTINCREASE 0 FREELISTS 1 
        FREELIST GROUPS 1 
        BUFFER_POOL DEFAULT 
        FLASH_CACHE DEFAULT 
        CELL_FLASH_CACHE DEFAULT)   
TABLESPACE "SYSTEM";
 


insert into "HOTEL"("ID","NAME","STARS") values (200,'Mandarin Oriental',4);
insert into "HOTEL"("ID","NAME","STARS") values (201,'Taj Palace',2);
insert into "HOTEL"("ID","NAME","STARS") values (202,'The Temple House',4);
insert into "HOTEL"("ID","NAME","STARS") values (203,'Kamalame Cay',2);
insert into "HOTEL"("ID","NAME","STARS") values (204,'Hotel Paracas,aLuxuryCollectionResort',3);
insert into "HOTEL"("ID","NAME","STARS") values (205,'Taj Palace',4);
insert into "HOTEL"("ID","NAME","STARS") values (206,'Mahali Mzuri, Masai Mara',1);
insert into "HOTEL"("ID","NAME","STARS") values (207,'Capella Bangkok',1);
insert into "HOTEL"("ID","NAME","STARS") values (208,'Grace Hotel',5);
insert into "HOTEL"("ID","NAME","STARS") values (209,'Hotel Fasano Boa Vista',1);
insert into "HOTEL"("ID","NAME","STARS") values (210,'Capella Bangkok',2);
insert into "HOTEL"("ID","NAME","STARS") values (211,'Grace Hotel',4);
insert into "HOTEL"("ID","NAME","STARS") values (212,'Taj Palace',1);
insert into "HOTEL"("ID","NAME","STARS") values (213,'Mahali Mzuri, Masai Mara',1);
insert into "HOTEL"("ID","NAME","STARS") values (214,'Shangri-La the Shard',5);
insert into "HOTEL"("ID","NAME","STARS") values (215,'Four Seasons Hotel',5);
